//
//  HUD.m
//  emBanpi
//
//  Created by 孟德正 on 2019/10/10.
//  Copyright © 2019 孟德正. All rights reserved.
//

#import "HUD.h"

@implementation HUD

+ (void)showHudWithTitle:(NSString *)title onView:(UIView *)view {
    MBProgressHUD * hud = [MBProgressHUD showHUDAddedTo:view animated:YES ];
    hud.mode = MBProgressHUDModeText;
    hud.contentColor = [UIColor whiteColor];
    hud.bezelView.backgroundColor = [UIColor colorWithWhite:0 alpha:0.5];
    hud.label.font = [UIFont systemFontOfSize:14];
    hud.label.text = title;
    
    [hud hideAnimated:YES afterDelay:1.5];
}

@end
