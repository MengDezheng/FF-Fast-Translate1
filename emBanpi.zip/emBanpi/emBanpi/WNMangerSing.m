//
//  WNMangerSing.m
//  WNSport
//
//  Created by 孟德正 on 2019/9/20.
//  Copyright © 2019 孟德正. All rights reserved.
//

#import "WNMangerSing.h"

@implementation WNMangerSing
+ (AFHTTPSessionManager *)sharedHTTPSession{
    static  AFHTTPSessionManager *manager;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        manager = [AFHTTPSessionManager manager];
        //        manager.requestSerializer.timeoutInterval = 30;
        //        [manager.requestSerializer  setValue:@"XMLHttpRequest" forHTTPHeaderField:@"X-Requested-With"];
    });
    return manager;
}
@end
