//
//  TableViewCell.h
//  emBanpi
//
//  Created by 孟德正 on 2019/10/10.
//  Copyright © 2019 孟德正. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface TableViewCell : UITableViewCell
@property(nonatomic,strong)UILabel *titleLab;
@property(nonatomic,strong)UIImageView *select;
@property(nonatomic,assign)NSInteger cellIndex;
@property(nonatomic,strong)NSMutableArray *dataArr;
@property(nonatomic,strong)NSString *title;
@end

NS_ASSUME_NONNULL_END
