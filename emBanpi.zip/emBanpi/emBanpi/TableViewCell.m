//
//  TableViewCell.m
//  emBanpi
//
//  Created by 孟德正 on 2019/10/10.
//  Copyright © 2019 孟德正. All rights reserved.
//

#import "TableViewCell.h"

@implementation TableViewCell

-(instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        self.backgroundColor = [UIColor whiteColor];
        self.selectionStyle = UITableViewCellSelectionStyleNone;
        [self createUI];
    }
    return self;
}

-(void)createUI{
    
    self.titleLab=[UILabel new];
    self.titleLab.textColor=RGBColor(26, 26, 26);
    self.titleLab.font=[UIFont systemFontOfSize:17*kScale];
    [self.contentView addSubview:self.titleLab];
    [self.titleLab mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerY.equalTo(self.contentView);
        make.left.mas_equalTo(21*kScale);
        make.height.mas_equalTo(20*kScale);
    }];
    
    self.select=[UIImageView new];
    self.select.hidden=YES;
    self.select.image=[UIImage imageNamed:@"baocun"];
    [self.contentView addSubview:self.select];
    [self.select mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerY.equalTo(self.contentView);
        make.right.mas_equalTo(-21*kScale);
        make.height.mas_equalTo(16*kScale);
        make.width.mas_equalTo(25*kScale);
    }];
    
}


-(void)setTitle:(NSString *)title{
    _title = title;
    self.titleLab.text=title;

}
@end
