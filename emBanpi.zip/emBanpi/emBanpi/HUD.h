//
//  HUD.h
//  emBanpi
//
//  Created by 孟德正 on 2019/10/10.
//  Copyright © 2019 孟德正. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface HUD : NSObject
//默认文字
+ (void)showHudWithTitle:(NSString *)title onView:(UIView *)view;
@end

NS_ASSUME_NONNULL_END
