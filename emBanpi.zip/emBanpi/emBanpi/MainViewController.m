//
//  MainViewController.m
//  emBanpi
//
//  Created by 孟德正 on 2019/10/9.
//  Copyright © 2019 孟德正. All rights reserved.
//

#import "MainViewController.h"
#import <CommonCrypto/CommonDigest.h>
#import "LeftViewController.h"
#import "RightViewController.h"
#import <AFNetworking.h>
#import <AVFoundation/AVFoundation.h>
@interface MainViewController ()<UITextViewDelegate,LeftViewControllerDelegate,RightViewControllerDelegate>
@property(nonatomic,strong)UIView *topView,*centerView,*bottomView;
@property(nonatomic,strong)UIImageView *topVideo,*centerVideo,*copView;
@property(nonatomic,strong)UITextView *textView;
@property(nonatomic,strong)UILabel *label,*placeLabel;
@property(nonatomic,assign)NSString *left;
@property(nonatomic,assign)NSString *right;
@end

@implementation MainViewController

-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    [self.navigationController.navigationBar setBackgroundImage:[UIImage imageNamed:@"huhuan"] forBarMetrics:UIBarMetricsDefault];
}
- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor=RGBColor(245, 245, 245);
    
    self.navigationController.navigationBar.barTintColor=RGBColor(54, 109, 127);
    self.navigationController.navigationBar.tintColor=[UIColor whiteColor];
    
    NSString *str = [[NSUserDefaults standardUserDefaults]objectForKey:@"lefttitle"];
    NSString *str1 = [[NSUserDefaults standardUserDefaults]objectForKey:@"righttitle"];
    
    if (str==nil) {
        str=@"EngLish";
    }
    
    if (str1==nil) {
        str1=@"Chinese";
    }
    
    self.navigationItem.leftBarButtonItem =[[UIBarButtonItem alloc]initWithTitle:str style:UIBarButtonItemStylePlain target:self action:@selector(selectLeftText)];
    self.navigationItem.rightBarButtonItem =[[UIBarButtonItem alloc]initWithTitle:str1 style:UIBarButtonItemStylePlain target:self action:@selector(selectRightText)];
    
    
    [self creatTopView];
    [self creatCenterView];
//    [self creatBottomView];
}

-(void)creatTopView{
    
    self.topView=[UIView new];
//                  self.topView.frame=CGRectMake(10, 0, 200, 120);
    self.topView.backgroundColor=[UIColor whiteColor];
    [self.view addSubview:self.topView];
    [self.topView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerX.equalTo(self.view);
        make.width.mas_equalTo(self.view);
        make.top.mas_equalTo(0);
        make.height.mas_equalTo(180*kScale);

    }];
    
    self.textView=[UITextView new];
    self.textView.backgroundColor=[UIColor whiteColor];
    self.textView.delegate=self;
    
    self.textView.font=[UIFont systemFontOfSize:17*kScale];
    [self.topView addSubview:self.textView];
    [self.textView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.height.mas_equalTo(120*kScale);
        make.width.mas_equalTo(kScreenW-20*kScale);
        make.center.equalTo(self.topView);
    }];
    
    
    self.placeLabel = [[UILabel alloc]initWithFrame:CGRectMake(3, 7, kScreenW-50, 20)];

    self.placeLabel.enabled = NO;

    self.placeLabel.text = @"Enter the text to be translated here";

    self.placeLabel.font =  [UIFont systemFontOfSize:17*kScale];

    self.placeLabel.textColor = [UIColor lightGrayColor];

    [self.textView addSubview:self.placeLabel];
    
    
    UITapGestureRecognizer *tap1=[[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(topVideoAction)];
    
    self.topVideo=[UIImageView new];
    self.topVideo.userInteractionEnabled=YES;
    [self.topVideo addGestureRecognizer:tap1];
    [self.topView addSubview:self.topVideo];
    self.topVideo.image = [UIImage imageNamed:@"sound"];
   
    [self.topVideo mas_makeConstraints:^(MASConstraintMaker *make) {
        make.width.mas_equalTo(23*kScale);
        make.height.mas_equalTo(18*kScale);
        make.left.mas_equalTo(16*kScale);
        make.bottom.mas_equalTo(-16*kScale);
    }];
    
    UIButton *btn=[UIButton buttonWithType:UIButtonTypeCustom];
    [btn setTitle:@"Determine" forState:UIControlStateNormal];
    [btn setFont:[UIFont systemFontOfSize:15*kScale]];
    [btn setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [btn addTarget:self action:@selector(Determine) forControlEvents:UIControlEventTouchUpInside];
    [self.topView addSubview:btn];
    [btn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.width.mas_equalTo(80*kScale);
        make.height.mas_equalTo(23*kScale);
        make.right.mas_equalTo(-16*kScale);
        make.bottom.mas_equalTo(-16*kScale);
    }];
    
    
}
-(void)creatCenterView{
    
    self.centerView=[UIView new];
    self.centerView.backgroundColor=[UIColor whiteColor];
    [self.view addSubview:self.centerView];
    [self.centerView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerX.width.equalTo(self.view);
        make.top.equalTo(self.topView.mas_bottom).offset(6*kScale);
        make.height.mas_equalTo(180*kScale);
        
    }];
    
    self.label=[UILabel new];
    self.label.backgroundColor=[UIColor whiteColor];
    self.label.textColor=RGBColor(26, 26, 26);
    self.label.font=[UIFont systemFontOfSize:17*kScale];
    [self.centerView addSubview:self.label];
    [self.label mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(20*kScale);
        make.width.mas_equalTo(kScreenW-20*kScale);
        make.centerX.equalTo(self.centerView);
    }];
    
    UITapGestureRecognizer *tap=[[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(centerVideoAction)];
    self.centerVideo=[UIImageView new];
    self.centerVideo.userInteractionEnabled=YES;
    [self.centerVideo addGestureRecognizer:tap];
    [self.centerView addSubview:self.centerVideo];
    self.centerVideo.image = [UIImage imageNamed:@"sound"];
   
  
    [self.centerVideo mas_makeConstraints:^(MASConstraintMaker *make) {
        make.width.mas_equalTo(23*kScale);
        make.height.mas_equalTo(18*kScale);
        make.left.mas_equalTo(16*kScale);
        make.bottom.mas_equalTo(-16*kScale);
    }];
    
    
    UITapGestureRecognizer *tap3=[[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(copyAction)];
     
     self.copView=[UIImageView new];
     self.copView.userInteractionEnabled=YES;
     [self.copView addGestureRecognizer:tap3];
     [self.centerView addSubview:self.copView];
     self.copView.image = [UIImage imageNamed:@"copy"];
    
     [self.copView mas_makeConstraints:^(MASConstraintMaker *make) {
         make.width.mas_equalTo(23*kScale);
         make.height.mas_equalTo(23*kScale);
         make.right.mas_equalTo(-16*kScale);
         make.bottom.mas_equalTo(-16*kScale);
     }];
     

    
}
-(void)copyAction{
    
    UIPasteboard *pasteboard = [UIPasteboard generalPasteboard];
    pasteboard.string = self.label.text;
    
    [HUD showHudWithTitle:@"Copy success" onView:self.view];
}
-(void)creatBottomView{
    
    self.bottomView=[UIView new];
    self.bottomView.backgroundColor=[UIColor whiteColor];
    [self.view addSubview:self.bottomView];
    [self.bottomView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerX.width.equalTo(self.view);
        make.top.equalTo(self.centerView.mas_bottom).offset(6*kScale);
        make.height.mas_equalTo(180*kScale);
        
    }];
    
    
}
-(void)Determine{
    
    [self loadData];
}

-(void)topVideoAction{
    
    NSString *to;
          NSString *str1 = [[NSUserDefaults standardUserDefaults]objectForKey:@"lefttitle"];
          
          if ([str1 isEqual:@"Chinese"]) {
              to=@"zh-CN";
          }else if ([str1 isEqual:@"English"]){
              to=@"en-US";
          }else if ([str1 isEqual:@"Japanese"]){
              to=@"ja-JP";
          }else if ([str1 isEqual:@"Cantonese"]){
              to=@"zh-HK";
          }else if ([str1 isEqual:@"Korean"]){
              to=@"ko-KR";
          }else if ([str1 isEqual:@"French"]){
              to=@"fr-FR";
          }else if ([str1 isEqual:@"Spanish"]){
              to=@"es-ES";
          }else if ([str1 isEqual:@"Russian"]){
              to=@"ru-RU";
          }else if ([str1 isEqual:@"German"]){
              to=@"de-DE";
          }else{
              to=@"zh-CN";
          }
    
    AVSpeechSynthesizer *synthesizer = [[AVSpeechSynthesizer alloc] init];

    AVSpeechUtterance *utterance = [AVSpeechUtterance speechUtteranceWithString:self.textView.text];    //设置你想说的话

    utterance.rate = AVSpeechUtteranceDefaultSpeechRate / 2; //设置语速

    utterance.voice = [AVSpeechSynthesisVoice voiceWithLanguage:to]; //设置哪国语言

    [synthesizer speakUtterance:utterance];//添加进入发出声音类
    //开始动画
//    [self.topVideo startAnimating];
//    //结束动画
//    [self.topVideo stopAnimating];
}


-(void)centerVideoAction{
    
   
    NSString *to;
       NSString *str1 = [[NSUserDefaults standardUserDefaults]objectForKey:@"righttitle"];
       
       if ([str1 isEqual:@"Chinese"]) {
           to=@"zh-CN";
       }else if ([str1 isEqual:@"English"]){
           to=@"en-US";
       }else if ([str1 isEqual:@"Japanese"]){
           to=@"ja-JP";
       }else if ([str1 isEqual:@"Cantonese"]){
           to=@"zh-HK";
       }else if ([str1 isEqual:@"Korean"]){
           to=@"ko-KR";
       }else if ([str1 isEqual:@"French"]){
           to=@"fr-FR";
       }else if ([str1 isEqual:@"Spanish"]){
           to=@"es-ES";
       }else if ([str1 isEqual:@"Russian"]){
           to=@"ru-RU";
       }else if ([str1 isEqual:@"German"]){
           to=@"de-DE";
       }else{
           to=@"zh-CN";
       }

    AVSpeechSynthesizer *synthesizer = [[AVSpeechSynthesizer alloc] init];

    AVSpeechUtterance *utterance = [AVSpeechUtterance speechUtteranceWithString:self.label.text];    //设置你想说的话

    utterance.rate = AVSpeechUtteranceDefaultSpeechRate / 2; //设置语速

    utterance.voice = [AVSpeechSynthesisVoice voiceWithLanguage:to]; //设置哪国语言

    [synthesizer speakUtterance:utterance];//添加进入发出声音类
    
}

- (void) textViewDidChange:(UITextView *)textView{

    if ([textView.text length] == 0) {

        [self.placeLabel setHidden:NO];

    }else{

        [self.placeLabel setHidden:YES];

    }

}


-(BOOL) textViewShouldBeginEditing:(UITextView *)textView{

    if(textView.tag == 0) {

        textView.text = @"";

        textView.textColor = [UIColor blackColor];

        textView.tag = 1;

    }

    return YES;

}


-(void)loadData{
    
    if (self.textView.text.length ==0) {
        
        return;
    }
        NSString *to;
        NSString *str1 = [[NSUserDefaults standardUserDefaults]objectForKey:@"righttitle"];
       
       if ([str1 isEqual:@"Chinese"]) {
           to=@"zh";
       }else if ([str1 isEqual:@"English"]){
           to=@"en";
       }else if ([str1 isEqual:@"Japanese"]){
           to=@"jp";
       }else if ([str1 isEqual:@"Cantonese"]){
           to=@"yue";
       }else if ([str1 isEqual:@"Korean"]){
           to=@"kor";
       }else if ([str1 isEqual:@"French"]){
           to=@"fra";
       }else if ([str1 isEqual:@"Spanish"]){
           to=@"spa";
       }else if ([str1 isEqual:@"Russian"]){
           to=@"ru";
       }else if ([str1 isEqual:@"German"]){
           to=@"de";
       }else{
           to=@"zh";
       }
       

    
    NSString *strHTTP=@"https://fanyi-api.baidu.com/api/trans/vip/translate";
    
    NSString *strSalt=@"1435660288";
    NSString *strText=self.textView.text;
    
    NSString *strAppID=@"20191008000339862";
    NSString *strKey=@"L8TfAzgOCElDaaxin5lv";

  
    //将请求参数中的 APPID(appid), 翻译query(q, 注意为UTF-8编码), 随机数(salt), 以及平台分配的密钥
    NSString *sign=[NSString stringWithFormat:@"%@%@%@%@",strAppID,strText,strSalt,strKey];
    NSString *utf= [sign stringByReplacingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
    NSString *md5Str=[self stringToMD5:sign];
   
    //对 q 进行 编码 (第二次使用)
    NSString *qEncoding = [strText stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
    
     NSString *url=[NSString stringWithFormat:@"%@?q=%@&from=%@&to=%@&appid=%@&salt=%@&sign=%@",strHTTP,qEncoding,@"auto",to,strAppID,strSalt,md5Str];
    [WNNetWorkManager getWithURL:url parameter:nil completeHandle:^(id  _Nonnull data, NSError * _Nonnull error) {
        
        NSLog(@"%@",data);
        NSString *resStr = [[data objectForKey:@"trans_result"] firstObject][@"dst"];
        self.label.text=resStr;
    }];
    

    

}

- (NSString *)stringToMD5:(NSString *) input {
    const char *cStr = [input UTF8String];
    unsigned char digest[CC_MD5_DIGEST_LENGTH];
    CC_MD5( cStr, strlen(cStr), digest ); // This is the md5 call
    NSMutableString *output = [NSMutableString stringWithCapacity:CC_MD5_DIGEST_LENGTH * 2];

    for(int i = 0; i < CC_MD5_DIGEST_LENGTH; i++)
        [output appendFormat:@"%02x", digest[i]];
    return output;
}

-(void)selectLeftText{
    LeftViewController *left=[LeftViewController new];
    left.delegate=self;
    [self.navigationController pushViewController:left animated:YES];
}
-(void)selectRightText{
    RightViewController *right=[RightViewController new];
    right.delegate=self;
    [self.navigationController pushViewController:right animated:YES];
}
- (void)showText:(NSString *)text{
    
    _left=text;
     [[NSUserDefaults standardUserDefaults]setObject:text forKey:@"lefttitle"];
    self.navigationItem.leftBarButtonItem =[[UIBarButtonItem alloc]initWithTitle:text style:UIBarButtonItemStylePlain target:self action:@selector(selectLeftText)];
    
}
-(void)showRightText:(NSString *)text{
    _left=text;
    [[NSUserDefaults standardUserDefaults]setObject:text forKey:@"righttitle"];
    self.navigationItem.rightBarButtonItem =[[UIBarButtonItem alloc]initWithTitle:text style:UIBarButtonItemStylePlain target:self action:@selector(selectRightText)];
}

#pragma mark ----------------文本视图代理------------
//点击视图隐藏键盘
-(void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event{
    [super touchesBegan:touches withEvent:event];
    [self.view endEditing:NO];
}
//return 隐藏键盘
-(BOOL)textFieldShouldReturn:(UITextField *)textField{
    [textField resignFirstResponder];
    return NO;
}

/*
ar-SA  沙特阿拉伯（阿拉伯文）

en-ZA, 南非（英文）

nl-BE, 比利时（荷兰文）

en-AU, 澳大利亚（英文）

th-TH, 泰国（泰文）

de-DE, 德国（德文）

en-US, 美国（英文）

pt-BR, 巴西（葡萄牙文）

pl-PL, 波兰（波兰文）

en-IE, 爱尔兰（英文）

el-GR, 希腊（希腊文）

id-ID, 印度尼西亚（印度尼西亚文）

sv-SE, 瑞典（瑞典文）

tr-TR, 土耳其（土耳其文）

pt-PT, 葡萄牙（葡萄牙文）

ja-JP, 日本（日文）

ko-KR, 南朝鲜（朝鲜文）

hu-HU, 匈牙利（匈牙利文）

cs-CZ, 捷克共和国（捷克文）

da-DK, 丹麦（丹麦文）

es-MX, 墨西哥（西班牙文）

fr-CA, 加拿大（法文）

nl-NL, 荷兰（荷兰文）

fi-FI, 芬兰（芬兰文）

es-ES, 西班牙（西班牙文）

it-IT, 意大利（意大利文）

he-IL, 以色列（希伯莱文，阿拉伯文）

no-NO, 挪威（挪威文）

ro-RO, 罗马尼亚（罗马尼亚文）

zh-HK, 香港（中文）

zh-TW, 台湾（中文）

sk-SK, 斯洛伐克（斯洛伐克文）

zh-CN, 中国（中文）

ru-RU, 俄罗斯（俄文）

en-GB, 英国（英文）

fr-FR, 法国（法文）

hi-IN  印度（印度文）
*/
@end
