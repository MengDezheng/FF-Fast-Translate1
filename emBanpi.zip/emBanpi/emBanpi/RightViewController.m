//
//  RightViewController.m
//  emBanpi
//
//  Created by 孟德正 on 2019/10/9.
//  Copyright © 2019 孟德正. All rights reserved.
//

#import "RightViewController.h"
#import "TableViewCell.h"
@interface RightViewController ()<UITableViewDelegate,UITableViewDataSource>
@property(nonatomic,strong)UITableView *tableView;
@property(nonatomic,strong)NSArray *arr;
@property(nonatomic,assign)NSInteger index;
@end

@implementation RightViewController


- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor=RGBColor(245, 245, 245);
    self.title=@"All language";
    [self.navigationController.navigationBar setTitleTextAttributes:@{NSFontAttributeName:[UIFont systemFontOfSize:19],NSForegroundColorAttributeName:[UIColor whiteColor]}];
    self.navigationController.navigationBar.tintColor=[UIColor whiteColor];
    self.navigationItem.leftBarButtonItem =[[UIBarButtonItem alloc]initWithTitle:@"Back" style:UIBarButtonItemStylePlain target:self action:@selector(back)];
    [self.navigationController.navigationBar setBackgroundImage:[UIImage imageNamed:@""] forBarMetrics:UIBarMetricsDefault];
    self.navigationController.navigationBar.barTintColor=RGBColor(54, 109, 127);
    
    [self creatUI];
}

-(void)creatUI{
    self.arr=@[@"Chinese",@"English",@"Japanese",@"Cantonese",@"Korean",@"French",@"Spanish",@"Russian",@"German"];
    self.tableView=[UITableView new];
    [self.view addSubview:self.tableView];
    self.tableView.rowHeight=59*kScale;
    self.tableView.delegate=self;
    self.tableView.dataSource = self;
    self.tableView.showsVerticalScrollIndicator = NO;
    self.tableView.tableFooterView = [[UIView alloc]init];
    [self.tableView mas_makeConstraints:^(MASConstraintMaker *make) {
        
        make.top.left.right.bottom.equalTo(self.view);
    }];
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    
    return self.arr.count;
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    static NSString *cellID = @"TableViewCell";
    TableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellID];
    if (cell == nil) {
        cell = [[TableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellID];
    }
    NSString *str = [[NSUserDefaults standardUserDefaults]objectForKey:@"rightselectindex"];
    if (indexPath.row==[str integerValue]) {
        cell.select.hidden=NO;
    }else{
        cell.select.hidden=YES;
    }
    
    cell.title=self.arr[indexPath.row];
    return cell;
    
}
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    
    _index=indexPath.row;
    NSString *str=[NSString stringWithFormat:@"%ld",(long)_index];
    [[NSUserDefaults standardUserDefaults]setObject:str forKey:@"rightselectindex"];
    [self.tableView reloadData];
    
}


-(void)back{
    NSString *str = [[NSUserDefaults standardUserDefaults]objectForKey:@"rightselectindex"];
    
     [_delegate showRightText:self.arr[[str integerValue]]];
    [self.navigationController popViewControllerAnimated:YES];
    
    
}


@end
