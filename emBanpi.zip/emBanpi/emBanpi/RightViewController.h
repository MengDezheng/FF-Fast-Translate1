//
//  RightViewController.h
//  emBanpi
//
//  Created by 孟德正 on 2019/10/9.
//  Copyright © 2019 孟德正. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN
@protocol RightViewControllerDelegate <NSObject>
-(void)showRightText:(NSString *)text;
@end

@interface RightViewController : UIViewController
@property(nonatomic) id<RightViewControllerDelegate> delegate;
@end

NS_ASSUME_NONNULL_END
